import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getProfile, saveProfile, RECOVERY_PATHWAYS } from '../utils/storage.js'

export default function Home() {
  const [profile, setProfile] = useState(getProfile())
  const navigate = useNavigate()

  useEffect(() => {
    if (!profile.startedAt) {
      const withDate = { ...profile, startedAt: new Date().toISOString() }
      setProfile(withDate)
      saveProfile(withDate)
    }
  }, [])

  function choosePathway(pathway) {
    const next = { ...profile, pathway }
    setProfile(next)
    saveProfile(next)
  }

  function updateName(name) {
    const next = { ...profile, name }
    setProfile(next)
    saveProfile(next)
  }

  const greetingName = profile.name ? `, ${profile.name}` : ''

  return (
    <div>
      <p className="page-subtitle" style={{ marginBottom: 2 }}>Welcome to</p>
      <h1 className="page-title" style={{ fontSize: 34 }}>Klea</h1>
      <p className="page-subtitle">
        A private space to track how you're healing{greetingName}, one day at a time.
      </p>

      <div className="card" style={{ marginBottom: 16 }}>
        <label htmlFor="name">Your name (optional)</label>
        <input
          id="name"
          type="text"
          placeholder="What should we call you?"
          value={profile.name || ''}
          onChange={(e) => updateName(e.target.value)}
          style={{ marginTop: 8 }}
        />
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <label>What are you recovering from?</label>
        <p style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 4 }}>
          This shapes the reflection prompts you'll see.
        </p>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 12 }}>
          {RECOVERY_PATHWAYS.map((path) => {
            const active = profile.pathway === path
            return (
              <button
                key={path}
                onClick={() => choosePathway(path)}
                className="pill-btn"
                style={{
                  background: active ? 'var(--deep-blue)' : 'var(--sky)',
                  color: active ? 'var(--white)' : 'var(--ink)',
                  fontSize: 13,
                  padding: '9px 14px',
                }}
              >
                {path}
              </button>
            )
          })}
        </div>
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <button className="pill-btn primary" style={{ flex: 1 }} onClick={() => navigate('/prompts')}>
          Reflect today
        </button>
        <button className="pill-btn sun" style={{ flex: 1 }} onClick={() => navigate('/symptoms')}>
          Log symptoms
        </button>
      </div>
    </div>
  )
}
