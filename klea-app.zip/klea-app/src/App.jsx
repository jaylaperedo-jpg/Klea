import { Routes, Route } from 'react-router-dom'
import BottomNav from './components/BottomNav.jsx'
import Home from './pages/Home.jsx'
import Prompts from './pages/Prompts.jsx'
import Symptoms from './pages/Symptoms.jsx'
import CalendarView from './pages/CalendarView.jsx'
import DayDetail from './pages/DayDetail.jsx'
import Settings from './pages/Settings.jsx'

export default function App() {
  return (
    <div className="app-shell">
      <main className="app-main">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/prompts" element={<Prompts />} />
          <Route path="/symptoms" element={<Symptoms />} />
          <Route path="/calendar" element={<CalendarView />} />
          <Route path="/calendar/:date" element={<DayDetail />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </main>
      <BottomNav />
    </div>
  )
}
