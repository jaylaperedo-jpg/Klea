import { NavLink } from 'react-router-dom'

const TABS = [
  { to: '/', label: 'Home', end: true },
  { to: '/prompts', label: 'Reflect' },
  { to: '/symptoms', label: 'Log' },
  { to: '/calendar', label: 'History' },
  { to: '/settings', label: 'Settings' },
]

export default function BottomNav() {
  return (
    <nav className="bottom-nav">
      {TABS.map((tab) => (
        <NavLink
          key={tab.to}
          to={tab.to}
          end={tab.end}
          className={({ isActive }) => 'nav-item' + (isActive ? ' active' : '')}
        >
          <span className="icon-dot" />
          {tab.label}
        </NavLink>
      ))}
    </nav>
  )
}
