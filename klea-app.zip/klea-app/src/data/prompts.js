// Each prompt can be tagged to specific pathways, or left untagged ("general")
// so it shows up for everyone regardless of what they picked on Home.

export const PROMPTS = [
  { id: 'g1', pathway: 'general', text: 'What is one thing your body did for you today, even a small one?' },
  { id: 'g2', pathway: 'general', text: 'Describe today in three words. No explanation needed.' },
  { id: 'g3', pathway: 'general', text: "What's something you needed today that you didn't get to ask for?" },
  { id: 'g4', pathway: 'general', text: 'Who checked in on you today, and how did it feel?' },
  { id: 'g5', pathway: 'general', text: 'What felt harder than it should have today?' },
  { id: 'g6', pathway: 'general', text: 'What is one thing you are proud of from the last 24 hours?' },
  { id: 'g7', pathway: 'general', text: 'If today had a color, what would it be?' },
  { id: 'g8', pathway: 'general', text: 'What are you looking forward to, even a little?' },
  { id: 'g9', pathway: 'general', text: 'What is your body asking for right now?' },
  { id: 'g10', pathway: 'general', text: 'Write a note to yourself from one week ago.' },

  { id: 'ps1', pathway: 'Post-surgery', text: 'How did your incision or surgical site feel today?' },
  { id: 'ps2', pathway: 'Post-surgery', text: 'What movement felt easier today than yesterday?' },
  { id: 'ps3', pathway: 'Post-surgery', text: 'Did you rest as much as your body asked for today?' },

  { id: 'ct1', pathway: 'Cancer treatment', text: 'How did your body respond to treatment today?' },
  { id: 'ct2', pathway: 'Cancer treatment', text: 'What got you through the hardest part of today?' },
  { id: 'ct3', pathway: 'Cancer treatment', text: 'What is one thing that tasted or felt good today?' },

  { id: 'it1', pathway: 'Injury / trauma recovery', text: 'What did your range of motion feel like today?' },
  { id: 'it2', pathway: 'Injury / trauma recovery', text: 'Did anything today remind you how far you have come?' },

  { id: 'af1', pathway: 'Autoimmune flare', text: 'Where in your body did you feel the flare most today?' },
  { id: 'af2', pathway: 'Autoimmune flare', text: 'What triggered or eased your symptoms today, if anything?' },

  { id: 'ce1', pathway: 'Cardiac event', text: 'How did your energy hold up through the day?' },
  { id: 'ce2', pathway: 'Cardiac event', text: 'What made your heart feel lighter today, literally or otherwise?' },

  { id: 'lh1', pathway: 'Long hospital stay', text: 'What is one thing about the hospital routine that felt bearable today?' },
  { id: 'lh2', pathway: 'Long hospital stay', text: 'What do you miss most about being home right now?' },

  { id: 'hp1', pathway: 'High-risk pregnancy', text: 'How did you and the baby feel today?' },
  { id: 'hp2', pathway: 'High-risk pregnancy', text: 'What worry can you set down for tonight?' },

  { id: 'um1', pathway: 'Undiagnosed / mystery illness', text: 'What symptom felt most present today?' },
  { id: 'um2', pathway: 'Undiagnosed / mystery illness', text: 'What helped you feel less alone in not knowing yet?' },
]

export function getDeckForPathway(pathway) {
  return PROMPTS.filter((p) => p.pathway === 'general' || p.pathway === pathway)
}
