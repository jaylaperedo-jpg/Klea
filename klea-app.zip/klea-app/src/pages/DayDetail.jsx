import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { getSymptomLogs, getSymptomTypes, deleteSymptomLog } from '../utils/storage.js'

export default function DayDetail() {
  const { date } = useParams()
  const navigate = useNavigate()
  const types = getSymptomTypes()
  const [logs, setLogs] = useState(() => getSymptomLogs().filter((l) => l.dateKey === date))
  const [index, setIndex] = useState(0)

  const log = logs[index]
  const prettyDate = new Date(date + 'T00:00:00').toLocaleDateString(undefined, {
    weekday: 'long', month: 'long', day: 'numeric',
  })

  function removeCurrent() {
    if (!log) return
    deleteSymptomLog(log.id)
    const next = logs.filter((l) => l.id !== log.id)
    setLogs(next)
    setIndex((i) => Math.min(i, Math.max(next.length - 1, 0)))
  }

  if (!log) {
    return (
      <div>
        <button className="pill-btn ghost" onClick={() => navigate('/calendar')} style={{ marginBottom: 16 }}>← Back</button>
        <p className="page-subtitle">No logs left for this day.</p>
      </div>
    )
  }

  return (
    <div>
      <button className="pill-btn ghost" onClick={() => navigate('/calendar')} style={{ marginBottom: 16 }}>← Back</button>
      <h1 className="page-title" style={{ fontSize: 22 }}>{prettyDate}</h1>

      {logs.length > 1 && (
        <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
          {logs.map((_, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                height: 4,
                borderRadius: 2,
                background: i === index ? 'var(--deep-blue)' : 'var(--periwinkle)',
              }}
            />
          ))}
        </div>
      )}

      {log.media && (
        <div className="card" style={{ padding: 0, overflow: 'hidden', marginBottom: 14 }}>
          {log.media.kind === 'photo' ? (
            <img src={log.media.dataUrl} alt="Symptom snapshot" style={{ width: '100%', display: 'block' }} />
          ) : (
            <video src={log.media.dataUrl} controls style={{ width: '100%', display: 'block' }} />
          )}
        </div>
      )}

      <div className="card" style={{ marginBottom: 14 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
          {types.map((t) => (
            <div key={t.id}>
              <span style={{ fontSize: 12, color: 'var(--ink-soft)', fontWeight: 700 }}>{t.label}</span>
              <p style={{ margin: '2px 0 0', fontFamily: 'var(--font-display)', fontSize: 20 }}>
                {log.values?.[t.id] ?? '—'}<span style={{ fontSize: 12, color: 'var(--ink-soft)' }}>/10</span>
              </p>
            </div>
          ))}
        </div>
        {log.notes && (
          <p style={{ marginTop: 16, marginBottom: 0, fontSize: 14, color: 'var(--ink)', lineHeight: 1.5 }}>
            {log.notes}
          </p>
        )}
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        {logs.length > 1 && (
          <>
            <button
              className="pill-btn ghost"
              style={{ flex: 1 }}
              disabled={index === 0}
              onClick={() => setIndex((i) => Math.max(0, i - 1))}
            >
              ← Earlier
            </button>
            <button
              className="pill-btn ghost"
              style={{ flex: 1 }}
              disabled={index === logs.length - 1}
              onClick={() => setIndex((i) => Math.min(logs.length - 1, i + 1))}
            >
              Later →
            </button>
          </>
        )}
      </div>
      <button className="pill-btn" style={{ width: '100%', marginTop: 10, background: '#F6E9E4', color: 'var(--danger)' }} onClick={removeCurrent}>
        Delete this log
      </button>
    </div>
  )
}
