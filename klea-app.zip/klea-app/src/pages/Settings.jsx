import { useState } from 'react'
import {
  getSymptomTypes,
  saveSymptomTypes,
  getProfile,
  saveProfile,
  RECOVERY_PATHWAYS,
} from '../utils/storage.js'

export default function Settings() {
  const [types, setTypes] = useState(getSymptomTypes())
  const [profile, setProfile] = useState(getProfile())
  const [newLabel, setNewLabel] = useState('')

  function renameType(id, label) {
    const next = types.map((t) => (t.id === id ? { ...t, label } : t))
    setTypes(next)
    saveSymptomTypes(next)
  }

  function removeType(id) {
    const next = types.filter((t) => t.id !== id)
    setTypes(next)
    saveSymptomTypes(next)
  }

  function addType() {
    if (!newLabel.trim()) return
    const id = newLabel.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-')
    const next = [...types, { id, label: newLabel.trim(), kind: 'scale' }]
    setTypes(next)
    saveSymptomTypes(next)
    setNewLabel('')
  }

  function choosePathway(pathway) {
    const next = { ...profile, pathway }
    setProfile(next)
    saveProfile(next)
  }

  return (
    <div>
      <h1 className="page-title">Settings</h1>
      <p className="page-subtitle">Make Klea match how you actually want to track your recovery.</p>

      <div className="card" style={{ marginBottom: 16 }}>
        <label>Recovery pathway</label>
        <select
          value={profile.pathway || ''}
          onChange={(e) => choosePathway(e.target.value)}
          style={{ marginTop: 8 }}
        >
          <option value="" disabled>Choose one</option>
          {RECOVERY_PATHWAYS.map((p) => (
            <option key={p} value={p}>{p}</option>
          ))}
        </select>
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <label>Symptoms to track</label>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 10 }}>
          {types.map((t) => (
            <div key={t.id} style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input
                type="text"
                value={t.label}
                onChange={(e) => renameType(t.id, e.target.value)}
              />
              <button
                onClick={() => removeType(t.id)}
                aria-label={`Remove ${t.label}`}
                className="pill-btn"
                style={{ background: '#F6E9E4', color: 'var(--danger)', padding: '10px 14px' }}
              >
                ✕
              </button>
            </div>
          ))}
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 14 }}>
          <input
            type="text"
            placeholder="Add a symptom, e.g. Nausea"
            value={newLabel}
            onChange={(e) => setNewLabel(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && addType()}
          />
          <button className="pill-btn primary" onClick={addType}>Add</button>
        </div>
      </div>

      <p style={{ fontSize: 12, color: 'var(--ink-soft)', textAlign: 'center' }}>
        Klea stores everything privately on this device. Nothing is uploaded anywhere.
      </p>
    </div>
  )
}
