import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getSymptomTypes, addSymptomLog, fileToDataUrl } from '../utils/storage.js'

function todayKey() {
  return new Date().toISOString().slice(0, 10)
}

export default function Symptoms() {
  const types = getSymptomTypes()
  const [values, setValues] = useState(() => Object.fromEntries(types.map((t) => [t.id, 5])))
  const [notes, setNotes] = useState('')
  const [media, setMedia] = useState(null) // { dataUrl, kind }
  const [saved, setSaved] = useState(false)
  const navigate = useNavigate()

  function setValue(id, v) {
    setValues((prev) => ({ ...prev, [id]: Number(v) }))
  }

  async function onFileChange(e) {
    const file = e.target.files?.[0]
    if (!file) return
    const dataUrl = await fileToDataUrl(file)
    setMedia({ dataUrl, kind: file.type.startsWith('video') ? 'video' : 'photo' })
  }

  function save() {
    addSymptomLog({
      dateKey: todayKey(),
      values,
      notes: notes.trim(),
      media,
    })
    setSaved(true)
    setTimeout(() => navigate('/calendar'), 700)
  }

  return (
    <div>
      <h1 className="page-title">Log symptoms</h1>
      <p className="page-subtitle">A quick check-in. Slide to where you're at right now.</p>

      <div className="card" style={{ marginBottom: 16, display: 'flex', flexDirection: 'column', gap: 18 }}>
        {types.map((t) => (
          <div key={t.id}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <label style={{ textTransform: 'none' }}>{t.label}</label>
              <span style={{ fontWeight: 700, color: 'var(--deep-blue)' }}>{values[t.id]}/10</span>
            </div>
            <input
              type="range"
              min="0"
              max="10"
              value={values[t.id]}
              onChange={(e) => setValue(t.id, e.target.value)}
              style={{ width: '100%', accentColor: 'var(--deep-blue)' }}
            />
          </div>
        ))}
      </div>

      <div className="card" style={{ marginBottom: 16 }}>
        <label>Notes (optional)</label>
        <textarea
          rows={3}
          placeholder="Anything you want to remember about today..."
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          style={{ marginTop: 8 }}
        />
      </div>

      <div className="card" style={{ marginBottom: 20 }}>
        <label>Photo or video (optional)</label>
        <p style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 4 }}>
          Stored privately on this device only.
        </p>
        <input type="file" accept="image/*,video/*" capture="environment" onChange={onFileChange} style={{ marginTop: 10 }} />
        {media && media.kind === 'photo' && (
          <img src={media.dataUrl} alt="Symptom snapshot" style={{ marginTop: 10, width: '100%', borderRadius: 12 }} />
        )}
        {media && media.kind === 'video' && (
          <video src={media.dataUrl} controls style={{ marginTop: 10, width: '100%', borderRadius: 12 }} />
        )}
      </div>

      <button className="pill-btn primary" style={{ width: '100%' }} onClick={save} disabled={saved}>
        {saved ? 'Saved ✓' : "Save today's log"}
      </button>
    </div>
  )
}
