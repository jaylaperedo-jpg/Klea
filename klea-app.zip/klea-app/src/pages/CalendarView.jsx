import { useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { getSymptomLogs } from '../utils/storage.js'

function monthLabel(date) {
  return date.toLocaleDateString(undefined, { month: 'long', year: 'numeric' })
}

export default function CalendarView() {
  const [cursor, setCursor] = useState(() => {
    const d = new Date()
    d.setDate(1)
    return d
  })
  const logs = getSymptomLogs()
  const navigate = useNavigate()

  const logsByDay = useMemo(() => {
    const map = {}
    for (const log of logs) {
      if (!map[log.dateKey]) map[log.dateKey] = []
      map[log.dateKey].push(log)
    }
    return map
  }, [logs])

  const year = cursor.getFullYear()
  const month = cursor.getMonth()
  const firstWeekday = new Date(year, month, 1).getDay()
  const daysInMonth = new Date(year, month + 1, 0).getDate()

  const cells = []
  for (let i = 0; i < firstWeekday; i++) cells.push(null)
  for (let day = 1; day <= daysInMonth; day++) cells.push(day)

  function keyFor(day) {
    const m = String(month + 1).padStart(2, '0')
    const d = String(day).padStart(2, '0')
    return `${year}-${m}-${d}`
  }

  function shiftMonth(delta) {
    const next = new Date(year, month + delta, 1)
    setCursor(next)
  }

  return (
    <div>
      <h1 className="page-title">History</h1>
      <p className="page-subtitle">Your symptom snapshots, day by day.</p>

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 }}>
        <button className="pill-btn ghost" style={{ padding: '8px 14px' }} onClick={() => shiftMonth(-1)}>←</button>
        <strong style={{ fontFamily: 'var(--font-display)', fontSize: 18 }}>{monthLabel(cursor)}</strong>
        <button className="pill-btn ghost" style={{ padding: '8px 14px' }} onClick={() => shiftMonth(1)}>→</button>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4, marginBottom: 6 }}>
        {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((d, i) => (
          <div key={i} style={{ textAlign: 'center', fontSize: 11, fontWeight: 700, color: 'var(--ink-soft)' }}>{d}</div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: 4 }}>
        {cells.map((day, i) => {
          if (!day) return <div key={i} />
          const key = keyFor(day)
          const dayLogs = logsByDay[key]
          const thumb = dayLogs?.find((l) => l.media)?.media
          return (
            <button
              key={i}
              onClick={() => dayLogs && navigate(`/calendar/${key}`)}
              style={{
                aspectRatio: '1',
                borderRadius: 10,
                border: 'none',
                padding: 0,
                overflow: 'hidden',
                position: 'relative',
                background: dayLogs ? 'var(--serene)' : 'var(--periwinkle)',
                opacity: dayLogs ? 1 : 0.45,
                cursor: dayLogs ? 'pointer' : 'default',
              }}
            >
              {thumb?.kind === 'photo' && (
                <img src={thumb.dataUrl} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
              )}
              <span
                style={{
                  position: 'absolute',
                  bottom: 3,
                  right: 4,
                  fontSize: 10,
                  fontWeight: 700,
                  color: thumb ? 'var(--white)' : 'var(--ink)',
                  textShadow: thumb ? '0 1px 3px rgba(0,0,0,0.5)' : 'none',
                }}
              >
                {day}
              </span>
            </button>
          )
        })}
      </div>

      <p style={{ fontSize: 13, color: 'var(--ink-soft)', marginTop: 16, textAlign: 'center' }}>
        Tap a day with a log to see photos, stats, and notes.
      </p>
    </div>
  )
}
