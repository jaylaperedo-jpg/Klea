# Klea

A private recovery companion — swipeable reflection prompts, symptom tracking with photo/video, and a BeReal-style calendar of your history. Everything is stored locally on your device (no backend, no account).

## Run it locally

```bash
npm install
npm run dev
```

Then open the local URL it prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

Outputs a static site to `dist/` that you can host anywhere (Vercel, Netlify, GitHub Pages, etc).

## What's in here

- `src/pages/Home.jsx` — pick your recovery pathway, which shapes which prompts you see
- `src/pages/Prompts.jsx` — swipeable reflection prompt deck (swipe right to answer, left to skip)
- `src/pages/Symptoms.jsx` — daily symptom check-in with sliders, notes, and photo/video
- `src/pages/CalendarView.jsx` — month grid, thumbnails on days you logged
- `src/pages/DayDetail.jsx` — swipe through a day's logs, see the photo, stats, and notes
- `src/pages/Settings.jsx` — rename/add/remove tracked symptoms, change pathway
- `src/utils/storage.js` — all localStorage read/write logic in one place
- `src/data/prompts.js` — the prompt bank, tagged by recovery pathway

## Things to tweak next

- Symptom categories default to Mobility, Pain, Appetite, Sleep, Energy, Overall mood, Motivation — edit the list in `src/utils/storage.js` (`DEFAULT_SYMPTOM_TYPES`) or just use the in-app Settings page
- Add more prompts per pathway in `src/data/prompts.js`
- Swap localStorage for a real backend later — everything reads/writes through `src/utils/storage.js`, so that's the only file you'd need to touch
