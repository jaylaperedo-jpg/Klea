// Simple localStorage-backed data layer for Klea.
// Everything lives under one namespaced key per collection so it's easy
// to swap for a real backend later without touching component code.

const KEYS = {
  profile: 'klea.profile',
  symptomTypes: 'klea.symptomTypes',
  symptomLogs: 'klea.symptomLogs',
  journalEntries: 'klea.journalEntries',
  promptDeck: 'klea.promptDeckState',
}

function read(key, fallback) {
  try {
    const raw = localStorage.getItem(key)
    return raw ? JSON.parse(raw) : fallback
  } catch {
    return fallback
  }
}

function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

export const DEFAULT_SYMPTOM_TYPES = [
  { id: 'mobility', label: 'Mobility', kind: 'scale' },
  { id: 'pain', label: 'Pain', kind: 'scale' },
  { id: 'appetite', label: 'Appetite', kind: 'scale' },
  { id: 'sleep', label: 'Sleep', kind: 'scale' },
  { id: 'energy', label: 'Energy', kind: 'scale' },
  { id: 'overallMood', label: 'Overall mood', kind: 'scale' },
  { id: 'motivation', label: 'Motivation', kind: 'scale' },
]

export const RECOVERY_PATHWAYS = [
  'Post-surgery',
  'Cancer treatment',
  'Injury / trauma recovery',
  'Autoimmune flare',
  'Cardiac event',
  'Long hospital stay',
  'High-risk pregnancy',
  'Undiagnosed / mystery illness',
]

export function getProfile() {
  return read(KEYS.profile, { name: '', pathway: '', startedAt: null })
}
export function saveProfile(profile) {
  write(KEYS.profile, profile)
}

export function getSymptomTypes() {
  return read(KEYS.symptomTypes, DEFAULT_SYMPTOM_TYPES)
}
export function saveSymptomTypes(types) {
  write(KEYS.symptomTypes, types)
}

export function getSymptomLogs() {
  return read(KEYS.symptomLogs, [])
}
export function addSymptomLog(entry) {
  const logs = getSymptomLogs()
  const withId = { id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...entry }
  write(KEYS.symptomLogs, [withId, ...logs])
  return withId
}
export function deleteSymptomLog(id) {
  write(KEYS.symptomLogs, getSymptomLogs().filter((l) => l.id !== id))
}

export function getJournalEntries() {
  return read(KEYS.journalEntries, [])
}
export function addJournalEntry(entry) {
  const entries = getJournalEntries()
  const withId = { id: crypto.randomUUID(), createdAt: new Date().toISOString(), ...entry }
  write(KEYS.journalEntries, [withId, ...entries])
  return withId
}
export function deleteJournalEntry(id) {
  write(KEYS.journalEntries, getJournalEntries().filter((e) => e.id !== id))
}

// Track which prompts have already been swiped away this session so the
// deck doesn't repeat itself immediately.
export function getSeenPromptIds() {
  return read(KEYS.promptDeck, [])
}
export function markPromptSeen(id) {
  const seen = getSeenPromptIds()
  write(KEYS.promptDeck, [...new Set([...seen, id])])
}
export function resetSeenPrompts() {
  write(KEYS.promptDeck, [])
}

// Convert an uploaded File (photo/video) into a base64 data URL so it can
// be stored in localStorage without a backend.
export function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}
