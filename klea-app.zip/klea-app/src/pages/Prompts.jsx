import { useMemo, useRef, useState } from 'react'
import { getDeckForPathway } from '../data/prompts.js'
import {
  getProfile,
  getSeenPromptIds,
  markPromptSeen,
  resetSeenPrompts,
  addJournalEntry,
} from '../utils/storage.js'

export default function Prompts() {
  const profile = getProfile()
  const fullDeck = useMemo(() => getDeckForPathway(profile.pathway), [profile.pathway])
  const seen = useMemo(() => getSeenPromptIds(), [])
  const [deck, setDeck] = useState(fullDeck.filter((p) => !seen.includes(p.id)))
  const [drag, setDrag] = useState({ x: 0, active: false })
  const [answering, setAnswering] = useState(null) // prompt being answered
  const [response, setResponse] = useState('')
  const startX = useRef(0)

  const current = deck[0]

  function onPointerDown(e) {
    startX.current = e.clientX
    setDrag({ x: 0, active: true })
  }
  function onPointerMove(e) {
    if (!drag.active) return
    setDrag({ x: e.clientX - startX.current, active: true })
  }
  function onPointerUp() {
    if (!drag.active) return
    if (drag.x > 110) {
      resolveSwipe('right')
    } else if (drag.x < -110) {
      resolveSwipe('left')
    } else {
      setDrag({ x: 0, active: false })
    }
  }

  function resolveSwipe(direction) {
    if (!current) return
    markPromptSeen(current.id)
    if (direction === 'right') {
      setAnswering(current)
      setResponse('')
    }
    setDeck((d) => d.slice(1))
    setDrag({ x: 0, active: false })
  }

  function saveResponse() {
    if (response.trim()) {
      addJournalEntry({ type: 'text', promptId: answering.id, promptText: answering.text, text: response.trim() })
    }
    setAnswering(null)
  }

  function reshuffle() {
    resetSeenPrompts()
    setDeck(fullDeck)
  }

  const rotation = drag.x / 18

  return (
    <div>
      <h1 className="page-title">Reflect</h1>
      <p className="page-subtitle">
        Swipe right to answer a prompt, left to skip it for now.
      </p>

      {!current && (
        <div className="card" style={{ textAlign: 'center', padding: 32 }}>
          <p style={{ fontFamily: 'var(--font-display)', fontSize: 20 }}>That's the whole deck.</p>
          <p style={{ color: 'var(--ink-soft)', fontSize: 14 }}>Come back tomorrow, or reshuffle to see them again.</p>
          <button className="pill-btn ghost" onClick={reshuffle} style={{ marginTop: 12 }}>
            Reshuffle deck
          </button>
        </div>
      )}

      {current && (
        <div style={{ position: 'relative', height: 340 }}>
          {deck[1] && (
            <div
              className="card"
              style={{
                position: 'absolute',
                inset: 0,
                transform: 'scale(0.95) translateY(10px)',
                opacity: 0.6,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
              }}
            />
          )}
          <div
            className="card"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
            style={{
              position: 'absolute',
              inset: 0,
              display: 'flex',
              flexDirection: 'column',
              justifyContent: 'space-between',
              cursor: 'grab',
              userSelect: 'none',
              touchAction: 'pan-y',
              transform: `translateX(${drag.x}px) rotate(${rotation}deg)`,
              transition: drag.active ? 'none' : 'transform 0.25s ease',
              background: drag.x > 40 ? 'var(--periwinkle)' : drag.x < -40 ? '#F6E9E4' : 'var(--white)',
            }}
          >
            <span style={{ fontSize: 12, fontWeight: 700, color: 'var(--deep-blue)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              {current.pathway === 'general' ? 'For you' : current.pathway}
            </span>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 24, lineHeight: 1.35, margin: 0 }}>
              {current.text}
            </p>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13, color: 'var(--ink-soft)' }}>
              <span>← skip</span>
              <span>answer →</span>
            </div>
          </div>
        </div>
      )}

      {current && (
        <div style={{ display: 'flex', gap: 10, marginTop: 20, justifyContent: 'center' }}>
          <button className="pill-btn ghost" onClick={() => resolveSwipe('left')}>Skip</button>
          <button className="pill-btn primary" onClick={() => resolveSwipe('right')}>Answer</button>
        </div>
      )}

      {answering && (
        <div style={overlayStyle}>
          <div className="card" style={{ width: '100%', maxWidth: 420 }}>
            <p style={{ fontFamily: 'var(--font-display)', fontSize: 18, marginTop: 0 }}>{answering.text}</p>
            <textarea
              rows={5}
              autoFocus
              placeholder="Write as much or as little as you want..."
              value={response}
              onChange={(e) => setResponse(e.target.value)}
            />
            <div style={{ display: 'flex', gap: 10, marginTop: 12 }}>
              <button className="pill-btn ghost" style={{ flex: 1 }} onClick={() => setAnswering(null)}>Cancel</button>
              <button className="pill-btn primary" style={{ flex: 1 }} onClick={saveResponse}>Save reflection</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

const overlayStyle = {
  position: 'fixed',
  inset: 0,
  background: 'rgba(46, 59, 69, 0.35)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  padding: 20,
  zIndex: 50,
}
